// L1F24BSCS0075 – Muhammad Arham
#include <iostream>
using namespace std;
class Vehicle 
{
protected:
    string brand;
    int wheel;
public:
    Vehicle();
    Vehicle(string brand, int wheel);
    void setBrand(string brand);
    void setWheel(int wheel);
    string getBrand();
    int getWheel();
    void displayVehicle();
};
