// L1F24BSCS0075 – Muhammad Arham
#include "Vehicle.h"
Vehicle::Vehicle()
{ 
    brand=""; 
    wheel=0; 
}
Vehicle::Vehicle(string brand,int wheel)
{ 
    this->brand=brand; 
    this->wheel=wheel; 
}
void Vehicle::setBrand(string brand)
{ 
    this->brand=brand;
}
void Vehicle::setWheel(int wheel)
{ 
    this->wheel=wheel; 
}
string Vehicle::getBrand()
{ 
    return brand; 
}
int Vehicle::getWheel()
{ 
    return wheel;
}
void Vehicle::displayVehicle(){
    cout<<"Brand = "<<brand<<endl;
    cout<<"Wheels = "<<wheel<<endl;
}
