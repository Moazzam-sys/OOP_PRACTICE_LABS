// L1F24BSCS0075 – Muhammad Arham
#include "SportsCar.h"
int main(){
    SportsCar s1("Ferrari",4,"F8",3900,340);
    SportsCar s2("Lamborghini",4,"Aventador",6500,350);
    s1.display();
    cout<<endl;
    s2.display();
    return 0;
}
