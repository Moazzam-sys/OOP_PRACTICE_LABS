// L1F24BSCS0075 – Muhammad Arham
#include "SportsCar.h"
SportsCar::SportsCar():Car()
{ 
    speed=1000; 
}
SportsCar::SportsCar(string brand,int wheel,string model,int engineCapacity,int speed)
:Car(brand,wheel,model,engineCapacity)
{ 
    this->speed=speed;
}
void SportsCar::setSpeed(int speed)
{ 
    this->speed=speed;
}
int SportsCar::getSpeed()
{ 
    return speed;
}
void SportsCar::display()
{
    displayCar();
    cout<<"Speed = "<<speed<<" Km/h"<<endl;
}
