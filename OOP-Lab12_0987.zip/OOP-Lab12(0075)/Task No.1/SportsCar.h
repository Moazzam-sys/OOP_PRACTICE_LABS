// L1F24BSCS0075 – Muhammad Arham
#include "Car.h"
class SportsCar : private Car 
{
protected:
    int speed;
public:
    SportsCar();
    SportsCar(string brand,int wheel,string model,int engineCapacity,int speed);
    void setSpeed(int speed);
    int getSpeed();
    void display();
};
