// L1F24BSCS0075 – Muhammad Arham
#include "Vehicle.h"
class Car : protected Vehicle 
{
protected:
    string model;
    int engineCapacity;
public:
    Car();
    Car(string brand,int wheel,string model,int engineCapacity);
    void setModel(string model);
    void setEngineCapacity(int engineCapacity);
    string getModel();
    int getEngineCapacity();
    void displayCar();
};
