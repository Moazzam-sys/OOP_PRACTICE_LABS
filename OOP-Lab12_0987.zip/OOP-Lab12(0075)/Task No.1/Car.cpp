// L1F20BSCSXXXX – Muhammad Arham
#include "Car.h"
Car::Car():Vehicle(){ model=""; engineCapacity=0; }
Car::Car(string brand,int wheel,string model,int engineCapacity):Vehicle(brand,wheel){
    this->model=model; this->engineCapacity=engineCapacity;
}
void Car::setModel(string model){ this->model=model; }
void Car::setEngineCapacity(int engineCapacity){ this->engineCapacity=engineCapacity; }
string Car::getModel(){ return model; }
int Car::getEngineCapacity(){ return engineCapacity; }
void Car::displayCar(){
    displayVehicle();
    cout<<"Model: "<<model<<endl;
    cout<<"Engine Capacity: "<<engineCapacity<<endl;
}
