// L1F24BSCS0075 � Muhammad Arham
#include "Shape.h"
Shape::Shape() 
{
    color = "Black";
}
Shape::Shape(string color) 
{
    this->color = color;
}
void Shape::setColor(string color)
{
    this->color = color;
}
string Shape::getColor() 
{
    return color;
}
void Shape::displayColor() 
{
    cout << "Color = " << color << endl;
}
