// L1F24BSCS0075 � Muhammad Arham
#include "Circle.h"
#include "Rectangle.h"
int main()
{
    Circle c("Red", 2.5);
    Rectangle r("Blue", 4, 5);
    c.displayCircle();
    cout << endl;
    r.displayRectangle();
    return 0;
}
