// L1F24BSCS0075 � Muhammad Arham
#include "Rectangle.h"
Rectangle::Rectangle() : Shape() 
{
    length = 0.5;
    width = 0.5;
}
Rectangle::Rectangle(string color, float length, float width) : Shape(color)
{
    this->length = length;
    this->width = width;
}
float Rectangle::calculateArea()
{
    return length * width;
}
void Rectangle::displayRectangle() 
{
    displayColor();
    cout << "Length = " << length << endl;
    cout << "Width = " << width << endl;
    cout << "Area = " << calculateArea() << endl;
}
