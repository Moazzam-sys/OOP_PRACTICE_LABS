// L1F24BSCS0075 � Muhammad Arham
#include "Shape.h"
class Rectangle : public Shape 
{
protected:
    float length;
    float width;
public:
    Rectangle();
    Rectangle(string color, float length, float width);
    float calculateArea();
    void displayRectangle();
};
