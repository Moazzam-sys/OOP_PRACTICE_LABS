// L1F24BSCS0075 � Muhammad Arham
#include <iostream>
using namespace std;
class Shape
{
protected:
    string color;
public:
    Shape();
    Shape(string color);
    void setColor(string color);
    string getColor();
    void displayColor();
};
