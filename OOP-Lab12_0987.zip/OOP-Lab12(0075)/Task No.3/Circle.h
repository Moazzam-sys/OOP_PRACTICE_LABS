// L1F24BSCS0075 � Muhammad Arham
#include "Shape.h"
class Circle : protected Shape 
{
protected:
    double radius;
public:
    Circle();
    Circle(string color, double radius);
    void setRadius(double radius);
    double getRadius();
    void displayCircle();
};
