// L1F24BSCS0075 � Muhammad Arham
#include "Circle.h"
Circle::Circle() : Shape()
{
    radius = 0.5;
}
Circle::Circle(string color, double radius) : Shape(color) 
{
    this->radius = radius;
}
void Circle::setRadius(double radius) 
{
    this->radius = radius;
}
double Circle::getRadius() 
{
    return radius;
}
void Circle::displayCircle()
{
    displayColor();
    cout << "Radius = " << radius << endl;
}
