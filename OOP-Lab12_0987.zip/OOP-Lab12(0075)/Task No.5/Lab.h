// L1F24BSCS0075 � Muhammad Arham
#include "Computer.h"
class Lab 
{
private:
    int labNumber;
    string labIncharge;
    Computer* systems[3];
public:
    Lab(int labNumber, string labIncharge, Computer* c1, Computer* c2, Computer* c3);
    void displayLab();
};