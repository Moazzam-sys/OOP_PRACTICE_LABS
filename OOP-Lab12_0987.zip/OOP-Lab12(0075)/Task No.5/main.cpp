// L1F24BSCS0075 � Muhammad Arham
#include "Lab.h"
int main()
{
    Computer c1("Dell", "i5", 8);
    Computer c2("HP", "i7", 16);
    Computer c3("Lenovo", "i3", 4);
    Lab lab(101, "Sir Ahmed", &c1, &c2, &c3);
    lab.displayLab();
    return 0;
}