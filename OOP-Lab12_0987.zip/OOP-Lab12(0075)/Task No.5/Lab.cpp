// L1F24BSCS0075 � Muhammad Arham
#include "Lab.h"
Lab::Lab(int labNumber, string labIncharge, Computer* c1, Computer* c2, Computer* c3) 
{
    this->labNumber = labNumber;
    this->labIncharge = labIncharge;
    systems[0] = c1;
    systems[1] = c2;
    systems[2] = c3;
}
void Lab::displayLab()
{
    cout << "Lab Number = " << labNumber << endl;
    cout << "Incharge = " << labIncharge << endl;
    for (int i = 0; i < 3; i++)
    {
        systems[i]->display();
        cout << endl;
    }
}
