// L1F24BSCS0075 � Muhammad Arham
#include <iostream>
using namespace std;
class Computer 
{
private:
    string brand;
    string processorType;
    int ramSize;
public:
    Computer(string brand, string processorType, int ramSize);
    void display();
};
