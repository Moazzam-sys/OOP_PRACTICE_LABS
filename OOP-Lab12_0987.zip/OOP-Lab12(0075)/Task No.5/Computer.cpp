// L1F24BSCS0075 � Muhammad Arham
#include "Computer.h"
Computer::Computer(string brand, string processorType, int ramSize)
{
    this->brand = brand;
    this->processorType = processorType;
    this->ramSize = ramSize;
}
void Computer::display() 
{
    cout << "Brand = " << brand << endl;
    cout << "Processor = " << processorType << endl;
    cout << "RAM = " << ramSize << " GB" << endl;
}