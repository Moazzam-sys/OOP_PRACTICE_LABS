// L1F24BSCS0075 � Muhammad Arham
#include "HeroVillager.h"
HeroVillager::HeroVillager()
{
    funFact = "";
}
HeroVillager::HeroVillager(string hName, string power, string vName, string occupation, string funFact)
    : Hero(hName, power), Villager(vName, occupation)
{
    this->funFact = funFact;
}
void HeroVillager::displayAll() 
{
    Hero::display();        
    Villager::display();    
    cout << "Fun Fact = " << funFact << endl;
}
