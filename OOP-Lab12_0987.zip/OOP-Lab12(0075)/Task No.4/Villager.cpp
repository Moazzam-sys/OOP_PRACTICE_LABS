// L1F24BSCS0075 � Muhammad Arham
#include "Villager.h"
Villager::Villager() 
{
    name = "";
    occupation = "";
}
Villager::Villager(string name, string occupation) 
{
    this->name = name;
    this->occupation = occupation;
}
void Villager::display() 
{
    cout << "Villager Name = " << name << endl;
    cout << "Occupation = " << occupation << endl;
}
istream& operator>>(istream& in, Villager& v)
{
    cout << "Enter Villager Name = ";
    in >> v.name;
    cout << "Enter Occupation = ";
    in >> v.occupation;
    return in;
}
ostream& operator<<(ostream& out, Villager& v) {
    out << "Villager Name = " << v.name << endl;
    out << "Occupation = " << v.occupation << endl;
    return out;
}
