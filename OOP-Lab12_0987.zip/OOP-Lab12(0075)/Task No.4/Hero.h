// L1F20BSCSXXXX � Muhammad Arham
#include <iostream>
using namespace std;
class Hero 
{
protected:
    string name;
    string superPower;
public:
    Hero();
    Hero(string name, string superPower);
    void display();
    friend istream& operator>>(istream&, Hero&);
    friend ostream& operator<<(ostream&, Hero&);
};
