// L1F24BSCS0075 � Muhammad Arham
#include <iostream>
using namespace std;
class Villager 
{
protected:
    string name;
    string occupation;
public:
    Villager();
    Villager(string name, string occupation);
    void display();
    friend istream& operator>>(istream& in, Villager& v);
    friend ostream& operator<<(ostream& out, Villager& v);
};
