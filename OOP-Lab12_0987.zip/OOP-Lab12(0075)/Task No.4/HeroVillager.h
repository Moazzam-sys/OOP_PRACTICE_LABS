// L1F24BSCS0075 � Muhammad Arham
#include "Hero.h"
#include "Villager.h"
class HeroVillager : public Hero, public Villager
{
private:
    string funFact;
public:
    HeroVillager();
    HeroVillager(string hName, string power,string vName, string occupation,string funFact);
    void displayAll();
};
