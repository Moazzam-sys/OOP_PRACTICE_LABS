// L1F24BSCS0075 � Muhammad Arham
#include "Hero.h"
Hero::Hero()
{
    name = "";
    superPower = "";
}
Hero::Hero(string name, string superPower)
{
    this->name = name;
    this->superPower = superPower;
}
void Hero::display() 
{
    cout << "Hero Name = " << name << endl;
    cout << "Super Power = " << superPower << endl;
}
istream& operator>>(istream& in, Hero& h)
{
    cout << "Enter Hero Name = ";
    in >> h.name;
    cout << "Enter Super Power = ";
    in >> h.superPower;
    return in;
}
ostream& operator<<(ostream& out, Hero& h) 
{
    out << "Hero Name = " << h.name << endl;
    out << "Super Power = " << h.superPower << endl;
    return out;
}
