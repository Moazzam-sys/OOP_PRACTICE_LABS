// L1F24BSCS0075 � Muhammad Arham
#include "HeroVillager.h"
int main()
{
    HeroVillager hv("Ali", "Fire","Ali", "Farmer","Loves pizza while fighting dragons");
    hv.displayAll();
    return 0;
}
