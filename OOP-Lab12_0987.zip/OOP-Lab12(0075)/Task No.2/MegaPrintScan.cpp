// L1F24BSCS0075 – Muhammad Arham
#include "MegaPrintScan.h"
MegaPrintScan::MegaPrintScan():Printer(),Scanner()
{ 
    price=0;
}
MegaPrintScan::MegaPrintScan(string pType,int pSpeed,string sRes,bool duplex,int price)
:Printer(pType,pSpeed),Scanner(sRes,duplex)
{ 
    this->price=price;
}
void MegaPrintScan::displayInfo()
{
    displayPrinter();
    displayScanner();
    cout<<"Price = "<<price<<endl;
}
