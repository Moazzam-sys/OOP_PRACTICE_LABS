// L1F20BSCS0075 – Muhammad Arham
#include "Printer.h"
Printer::Printer()
{ 
    printerType=""; 
    printSpeed=0;
}
Printer::Printer(string printerType,int printSpeed)
{
    this->printerType=printerType; this->printSpeed=printSpeed;
}
void Printer::displayPrinter()
{
    cout<<"Printer Type = "<<printerType<<endl;
    cout<<"Print Speed = "<<printSpeed<<endl;
}
