// L1F20BSCS0075 – Muhammad Arham
#include <iostream>
using namespace std;
class Printer 
{
protected:
    string printerType;
    int printSpeed;
public:
    Printer();
    Printer(string printerType,int printSpeed);
    void displayPrinter();
};
