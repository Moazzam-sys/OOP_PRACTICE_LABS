// L1F24BSCS0075 – Muhammad Arham
#include "Printer.h"
#include "Scanner.h"
class MegaPrintScan : public Printer, public Scanner 
{
protected:
    int price;
public:
    MegaPrintScan();
    MegaPrintScan(string pType,int pSpeed,string sRes,bool duplex,int price);
    void displayInfo();
};
