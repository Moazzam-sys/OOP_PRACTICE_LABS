// L1F24BSCS0075 – Muhammad Arham
#include "MegaPrintScan.h"
int main()
{
    MegaPrintScan m("Laser",40,"1200dpi",true,75000);
    m.displayInfo();
    return 0;
}
