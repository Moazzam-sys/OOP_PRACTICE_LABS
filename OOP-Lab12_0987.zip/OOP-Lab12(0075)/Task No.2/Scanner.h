// L1F24BSCS0075 – Muhammad Arham
#include <iostream>
using namespace std;
class Scanner 
{
protected:
    string scanResolution;
    bool duplex;
public:
    Scanner();
    Scanner(string scanResolution,bool duplex);
    void displayScanner();
};
