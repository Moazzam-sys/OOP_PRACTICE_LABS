// L1F20BSCSXXXX – Muhammad Arham
#include "Scanner.h"
Scanner::Scanner()
{ 
    scanResolution=""; 
    duplex=false; 
}
Scanner::Scanner(string scanResolution,bool duplex)
{
    this->scanResolution=scanResolution; 
    this->duplex=duplex;
}
void Scanner::displayScanner()
{
    cout<<"Scan Resolution = "<<scanResolution<<endl;
    cout<<"Duplex = "<<duplex<<endl;
}
