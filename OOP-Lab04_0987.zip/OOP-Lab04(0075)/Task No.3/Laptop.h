#include<iostream>
using namespace std;
class Laptop
{
private:
    string brand;
    int ramSize;
    float price;
public:
    Laptop(string b, int r, float p); // Parameterized constructor
    void setBrand(string b);
    void setRamSize(int r);
    void setPrice(float p);
    string getBrand();
    int getRamSize();
    float getPrice();
    void display();
};


