#include "Laptop.h"
Laptop::Laptop(string b, int r, float p) // Parameterized constructor
{
    brand = b;
    ramSize = r;
    price = p;
}
void Laptop::setBrand(string b)
{
    brand = b;
}
void Laptop::setRamSize(int r) 
{
    ramSize = r;
}
void Laptop::setPrice(float p) 
{
    price = p;
}
string Laptop::getBrand()
{
    return brand;
}
int Laptop::getRamSize() 
{
    return ramSize;
}
float Laptop::getPrice()
{
    return price;
}
void Laptop:: display()
{
    cout << "Brand = " << brand << ", RAM = " << ramSize << " GB" <<  ", Price = $" << price << endl;
}
