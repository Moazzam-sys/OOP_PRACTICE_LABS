#include "Laptop.h"
using namespace std;
int main()
{
    //using parameterized constructor
    Laptop laptop1("Dell", 16, 1200.50);
    Laptop laptop2("HP", 8, 850.75);
    cout << endl;
    //using getter functions
    cout << "Laptop Details" << endl;
    cout << "Laptop 1" << endl;
    cout<<"Brand = " << laptop1.getBrand() << ", RAM = " << laptop1.getRamSize() << " GB" << ", Price = $" << laptop1.getPrice() << endl;
    cout << "Laptop 2" << endl;
    cout << "Brand = " << laptop2.getBrand() << ", RAM = " << laptop2.getRamSize() << " GB" << ", Price = $" << laptop2.getPrice() << endl;
    cout << endl;
    // using display() function
    cout << "Laptop Details" << endl;
    laptop1.display();
    laptop2.display();

    return 0;
}
