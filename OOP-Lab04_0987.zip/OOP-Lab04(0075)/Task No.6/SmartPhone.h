#include <iostream>
using namespace std;
class SmartPhone
{
private:
    string brand;
    string model;
    float price;
    int storage;
public:
    SmartPhone(); //Default constructor
    SmartPhone(string b, string m, float p, int s); //parameterized constructor
    SmartPhone(string b, string m); //constructor (brand + model only)
    ~SmartPhone();  // Destructor
    void setBrand(string b);
    void setModel(string m);
    void setPrice(float p);
    void setStorage(int s);
    string getBrand();
    string getModel();
    float getPrice();
    int getStorage();
    void displayDetails();
};



