#include "SmartPhone.h"
SmartPhone::SmartPhone()
{
    brand = "Unknown";
    model = "Unknown";
    price = 0.0;
    storage = 0;
    cout << "Default Constructor Called" << endl;
}
SmartPhone::SmartPhone(string b, string m, float p, int s)
{
    brand = b;
    model = m;
    price = p;
    storage = s;
    cout << "Full Parameterized Constructor Called for " << brand << " " << model << endl;
}
SmartPhone::SmartPhone(string b, string m)
{
    brand = b;
    model = m;
    price = 0.0;
    storage = 0;
    cout << "Partial Constructor Called for " << brand << " " << model << endl;
}

SmartPhone::~SmartPhone()
{
    cout << "SmartPhone object destroyed. Memory released successfully" << endl;
}
void SmartPhone::setBrand(string b)
{
    brand = b;
}
void SmartPhone::setModel(string m)
{
    model = m;
}
void SmartPhone::setPrice(float p)
{
    price = p;
}
void SmartPhone::setStorage(int s)
{
    storage = s;
}
string SmartPhone::getBrand()
{
    return brand;
}
string SmartPhone::getModel()
{
    return model;
}
float SmartPhone::getPrice()
{
    return price;
}
int SmartPhone::getStorage()
{
    return storage;
}
void SmartPhone::displayDetails()
{
    cout << "Brand = " << brand << "Model = " << model << "Price = $" << price << "Storage = " << storage << " GB" << endl;
}
