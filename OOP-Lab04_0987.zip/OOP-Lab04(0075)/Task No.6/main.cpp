#include "SmartPhone.h"
int main()
{
    SmartPhone phone1; // Default constructor
    SmartPhone phone2("Samsung", "Galaxy S23"); // constructor(brand and model only)
    SmartPhone phone3("Apple", "iPhone 15 Pro", 1450.99, 256); // parameterized constructor
    cout << endl;
    cout << "Smartphone Details" << endl;
    phone1.displayDetails();
    phone2.displayDetails();
    phone3.displayDetails();
    //setter
    phone2.setPrice(999.99);
    phone2.setStorage(128);
    cout << endl;
    cout << "After updating phone2 details" << endl;
    phone2.displayDetails();
    cout << endl;
    //destructor message
    cout << "Program ending" << endl;
    return 0;
}
