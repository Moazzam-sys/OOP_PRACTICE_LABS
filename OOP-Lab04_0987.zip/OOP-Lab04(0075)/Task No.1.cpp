// Muhammad Arham
// L1F24BSCS0075
#include <iostream> 
using namespace std;

class Student
{
private:
	string name;
	int age;
	float* marks;   

public:
	Student()
	{
		name = "Unknown";
		age = 0;
		marks = new float(0); 
		cout << "Default Constructor Called" << endl;
	}

	Student(string n, int a, float m)
	{
		name = n;
		age = a;
		// Error 1: marks was never allocated before dereferencing (*marks = m;)
		marks = new float(m);
		cout << "Parameterized Constructor Called" << endl;
	}

	void display()
	{
		//Error 2: printing marks gives address not the actual value
		cout << "Name: " << name << ", Age: " << age << ", Marks: " << *marks << endl;
	}

	~Student()
	{
		delete marks;   // Correct memory deallocation
		cout << "Destructor called for " << name << endl;
	}
};

int main()
{
	Student s1;                   
	Student s2("Afham", 22, 88.5); 
	s1.display();  
	s2.display();  
	return 0;
}
