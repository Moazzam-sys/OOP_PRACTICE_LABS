#include "Car.h"
using namespace std;
int main()
{
    Car car1, car2, car3;
    car1.setBrandName("Toyota");
    car1.setModelYear(2020);
    car2.setBrandName("Honda");
    car2.setModelYear(2022);
    car3.setBrandName("Kia");
    car3.setModelYear(2024);
    cout << endl;
    cout << "Car Details =" << endl;
    cout << "Car 1 = Brand = " << car1.getBrandName() << ", Model Year = " << car1.getModelYear() << endl;
    cout << "Car 2 = Brand = " << car2.getBrandName() << ", Model Year = " << car2.getModelYear() << endl;
    cout << "Car 3 = Brand = " << car3.getBrandName() << ", Model Year = " << car3.getModelYear() << endl;
    cout << endl;
    car1.display();
    car2.display();
    car3.display();
    return 0;
}
