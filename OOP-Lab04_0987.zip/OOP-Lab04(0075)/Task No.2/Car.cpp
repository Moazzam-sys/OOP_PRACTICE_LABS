#include "Car.h"
Car::Car()
{
    brandName = "Unknown";
    modelYear = 0;
}
void Car::setBrandName(string name)
{
    brandName = name;
}
void Car::setModelYear(int year)
{
    modelYear = year;
}
string Car::getBrandName()
{
    return brandName;
}
int Car::getModelYear()
{
    return modelYear;
}
void Car::display()
{
    cout << "Brand = " << brandName << ", Model Year = " << modelYear << endl;
}

