#include <iostream>
using namespace std;
class Car
{
private:
    string brandName;
    int modelYear;
public:
    Car();
    void setBrandName(string name);
    void setModelYear(int year);
    string getBrandName();
    int getModelYear();
    void display();
};