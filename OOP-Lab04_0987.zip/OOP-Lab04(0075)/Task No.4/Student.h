#include <iostream>
using namespace std;
class Student 
{
private:
    string name;
    int rollNumber;
    double cgpa;
public:
    Student(); // using default constructor
    Student(string n, int r, double c = 0.0); // using parameterized constructor
    void setName(string n);
    void setRollNumber(int r);
    void setCgpa(double c);
    string getName();
    int getRollNumber();
    double getCgpa();
    void display();
};




