#include "Student.h"
Student::Student()
{
    name = "Unknown";
    rollNumber = 0;
    cgpa = 0.0;
}
Student::Student(string n, int r, double c) 
{
    name = n;
    rollNumber = r;
    cgpa = c;
}
void Student::setName(string n) 
{
    name = n;
}
void Student::setRollNumber(int r)
{
    rollNumber = r;
}
void Student::setCgpa(double c) 
{
    cgpa = c;
}
string Student::getName() 
{
    return name;
}
int Student::getRollNumber()
{
    return rollNumber;
}
double Student::getCgpa() 
{
    return cgpa;
}
void Student::display()
{
    cout << "Name = " << name<< ", Roll Number = " << rollNumber << ", CGPA = " << cgpa << endl;
}
