#include "Student.h"
using namespace std;
int main()
{ 
    Student s1; //default constructor
    Student s2("Arham", 101, 3.8); //parameterized constructor 
    Student s3("Ali", 102);  //  parameterized constructor CGPA defaults to 0.0
    cout << endl;
    cout << "Displaying Student Details " << endl;
    s1.display();
    s2.display();
    s3.display();
    // setters
    s1.setName("Hassan");
    s1.setRollNumber(103);
    s1.setCgpa(3.5);
    cout << endl;
    cout << "After updating s1" << endl;
    cout << "Name = " << s1.getName() << ", Roll Number = " << s1.getRollNumber() << ", CGPA = " << s1.getCgpa() << endl;
    return 0;
}
