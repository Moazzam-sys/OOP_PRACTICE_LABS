#include "Employee.h"
using namespace std;
int main()
{   
    Employee e1; //default constructor
    Employee e2("Muhammad Arham", 85000, "Software Engineer"); //parameterized constructor
    cout << endl;
    cout << "Employee Details" << endl;
    e1.display();
    e2.display();
    //using setters
    e1.setEmpName("Ali Raza");
    e1.setSalary(60000);
    e1.setDesignation("Web Developer");
    cout << endl;
    // using getters
    cout << "Updated Employee Details" << endl;
    cout << "Name = " << e1.getEmpName() << ", Salary = $" << e1.getSalary() << ", Designation = " << e1.getDesignation() << endl;
    return 0;
}
