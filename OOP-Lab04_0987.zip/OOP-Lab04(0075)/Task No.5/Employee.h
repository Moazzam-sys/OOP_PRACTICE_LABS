#include <iostream>
using namespace std;
class Employee
{
private:
    string empName;
    double salary;
    string designation;
public:
    Employee();// Default Constructor
    Employee(string name, double sal, string desig); // Parameterized Constructor
    ~Employee(); //Destructor
    void setEmpName(string name);
    void setSalary(double sal);
    void setDesignation(string desig);
    string getEmpName();
    double getSalary();
    string getDesignation();
    void display();
};
