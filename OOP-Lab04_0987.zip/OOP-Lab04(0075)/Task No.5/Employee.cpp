#include "Employee.h"
Employee::Employee()
{
    empName = "Unknown";
    salary = 0.0;
    designation = "Not Assigned";
    cout << "Default Constructor Called" << endl;
}
Employee::Employee(string name, double sal, string desig)
{
    empName = name;
    salary = sal;
    designation = desig;
    cout << "Parameterized Constructor Called for " << empName << endl;
}
Employee::~Employee()
{
    cout << "Destructor Called You Goodbye " << empName << "!" << endl;
}
void Employee::setEmpName(string name)
{
    empName = name;
}
void Employee::setSalary(double sal)
{
    salary = sal;
}
void Employee::setDesignation(string desig)
{
    designation = desig;
}
string Employee::getEmpName()
{
    return empName;
}
double Employee::getSalary()
{
    return salary;
}
string Employee::getDesignation()
{
    return designation;
}
void Employee::display()
{
    cout << "Employee Name = " << empName << ", Salary = $" << salary << ", Designation = " << designation << endl;
}
